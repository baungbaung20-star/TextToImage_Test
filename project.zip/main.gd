extends Control
## On-device text-to-image UI.
## Backend 1 (preferred): Android plugin "OnDeviceImageGen" (MediaPipe Image Generator).
## Backend 2 (fallback):  stable-diffusion.cpp server on http://127.0.0.1:7860.
const PLUGIN_NAME := "OnDeviceImageGen"
var plugin: Object = null

const DEFAULT_URL := "http://127.0.0.1:7860"
const TXT2IMG_PATH := "/sdapi/v1/txt2img"

var prompt_edit: TextEdit
var url_edit: LineEdit
var steps_spin: SpinBox
var seed_spin: SpinBox
var size_opt: OptionButton
var generate_btn: Button
var status_label: Label
var preview: TextureRect
var save_btn: Button
var http: HTTPRequest
var current_image: Image
var busy := false
var elapsed := 0.0


func _ready() -> void:
	_build_ui()
	http = HTTPRequest.new()
	http.timeout = 0 # generation can take minutes on a phone
	http.request_completed.connect(_on_request_completed)
	add_child(http)
	_setup_plugin()


func _setup_plugin() -> void:
	if not Engine.has_singleton(PLUGIN_NAME):
		status_label.text = "Plugin မတွေ့ပါ - server mode (Termux) သုံးပါမယ်"
		return
	plugin = Engine.get_singleton(PLUGIN_NAME)
	plugin.connect("model_loaded", _on_model_loaded)
	plugin.connect("progress", _on_progress)
	plugin.connect("image_ready", _on_image_ready)
	plugin.connect("error", _on_error)
	url_edit.visible = false
	steps_spin.value = 20 # MediaPipe SD 1.5 is not a distilled model
	generate_btn.disabled = true
	status_label.text = "Model loading..."
	plugin.loadModel("") # "" = default dir: <external files>/image_generator


func _on_model_loaded() -> void:
	generate_btn.disabled = false
	status_label.text = "Model ready"


func _on_progress(step: int, total: int) -> void:
	status_label.text = "Step %d / %d" % [step, total]


func _on_image_ready(path: String) -> void:
	busy = false
	generate_btn.disabled = false
	var img := Image.new()
	if img.load(path) != OK:
		status_label.text = "PNG ဖတ်မရပါ: " + path
		return
	_show_image(img)


func _on_error(message: String) -> void:
	busy = false
	generate_btn.disabled = false
	status_label.text = "Error: " + message


func _process(delta: float) -> void:
	if busy and plugin == null:
		elapsed += delta
		status_label.text = "Generating... %d စက္ကန့် (ဖုန်းမှာ ကြာနိုင်ပါတယ်)" % int(elapsed)


func _build_ui() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	add_child(margin)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 14)
	margin.add_child(vbox)

	var title := Label.new()
	title.text = "On-device Text to Image"
	title.add_theme_font_size_override("font_size", 32)
	vbox.add_child(title)

	url_edit = LineEdit.new()
	url_edit.text = DEFAULT_URL
	url_edit.placeholder_text = "Server URL"
	vbox.add_child(url_edit)

	prompt_edit = TextEdit.new()
	prompt_edit.placeholder_text = "Prompt ရိုက်ထည့်ပါ... (English က ပိုကောင်းပါတယ်)"
	prompt_edit.custom_minimum_size = Vector2(0, 150)
	prompt_edit.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	prompt_edit.text = "a cozy wooden cabin in a snowy forest at sunset, detailed, digital art"
	vbox.add_child(prompt_edit)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	vbox.add_child(row)

	row.add_child(_label("Steps"))
	steps_spin = SpinBox.new()
	steps_spin.min_value = 1
	steps_spin.max_value = 50
	steps_spin.value = 4 # distilled models (SD-Turbo etc.) need only 1-4
	row.add_child(steps_spin)

	row.add_child(_label("Seed"))
	seed_spin = SpinBox.new()
	seed_spin.min_value = 0
	seed_spin.max_value = 2147483647
	seed_spin.value = 0 # 0 = random
	row.add_child(seed_spin)

	var row2 := HBoxContainer.new()
	row2.add_theme_constant_override("separation", 12)
	vbox.add_child(row2)
	row2.add_child(_label("Size"))
	size_opt = OptionButton.new()
	for s in [256, 384, 512]:
		size_opt.add_item("%dx%d" % [s, s], s)
	size_opt.select(2)
	row2.add_child(size_opt)

	generate_btn = Button.new()
	generate_btn.text = "Generate"
	generate_btn.custom_minimum_size = Vector2(0, 80)
	generate_btn.pressed.connect(_on_generate_pressed)
	vbox.add_child(generate_btn)

	status_label = Label.new()
	status_label.text = "Ready"
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vbox.add_child(status_label)

	preview = TextureRect.new()
	preview.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	preview.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	preview.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(preview)

	save_btn = Button.new()
	save_btn.text = "Save"
	save_btn.disabled = true
	save_btn.custom_minimum_size = Vector2(0, 70)
	save_btn.pressed.connect(_on_save_pressed)
	vbox.add_child(save_btn)


func _label(t: String) -> Label:
	var l := Label.new()
	l.text = t
	return l


func _on_generate_pressed() -> void:
	if busy:
		return
	var prompt := prompt_edit.text.strip_edges()
	if prompt.is_empty():
		status_label.text = "Prompt ထည့်ပါ"
		return
	var seed_value := int(seed_spin.value)
	if seed_value == 0:
		seed_value = randi() % 2147483647
	if plugin:
		busy = true
		elapsed = 0.0
		generate_btn.disabled = true
		save_btn.disabled = true
		status_label.text = "Generating... (seed %d)" % seed_value
		plugin.generate(prompt, int(steps_spin.value), seed_value)
		return
	var px := size_opt.get_selected_id()
	var body := JSON.stringify({
		"prompt": prompt,
		"steps": int(steps_spin.value),
		"seed": seed_value,
		"width": px,
		"height": px,
	})
	var url := url_edit.text.strip_edges().rstrip("/") + TXT2IMG_PATH
	var err := http.request(url, ["Content-Type: application/json"], HTTPClient.METHOD_POST, body)
	if err != OK:
		status_label.text = "Request မပို့နိုင်ပါ (error %d). Server URL ကိုစစ်ပါ" % err
		return
	busy = true
	elapsed = 0.0
	generate_btn.disabled = true
	save_btn.disabled = true


func _on_request_completed(result: int, code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	busy = false
	generate_btn.disabled = false
	if result != HTTPRequest.RESULT_SUCCESS:
		status_label.text = "Server နဲ့ မချိတ်ဆက်နိုင်ပါ (result %d). Termux မှာ sd-server run နေလား စစ်ပါ" % result
		return
	if code != 200:
		status_label.text = "Server error %d: %s" % [code, body.get_string_from_utf8().left(200)]
		return
	var data = JSON.parse_string(body.get_string_from_utf8())
	if typeof(data) != TYPE_DICTIONARY or not data.has("images") or data["images"].is_empty():
		status_label.text = "Server ကပြန်လာတဲ့ response ကို နားမလည်ပါ"
		return
	var raw := Marshalls.base64_to_raw(str(data["images"][0]))
	var img := Image.new()
	var err := img.load_png_from_buffer(raw)
	if err != OK:
		err = img.load_jpg_from_buffer(raw)
	if err != OK:
		err = img.load_webp_from_buffer(raw)
	if err != OK:
		status_label.text = "ပုံဖတ်မရပါ (error %d)" % err
		return
	_show_image(img)


func _show_image(img: Image) -> void:
	current_image = img
	preview.texture = ImageTexture.create_from_image(img)
	save_btn.disabled = false
	status_label.text = "Done (%dx%d) - %d စက္ကန့်" % [img.get_width(), img.get_height(), int(elapsed)]


func _on_save_pressed() -> void:
	if current_image == null:
		return
	var fname := "img_%d.png" % Time.get_unix_time_from_system()
	var pictures := OS.get_system_dir(OS.SYSTEM_DIR_PICTURES)
	if not pictures.is_empty():
		var path := pictures.path_join(fname)
		if current_image.save_png(path) == OK:
			status_label.text = "Saved: " + path
			return
	# Fallback: app-private folder
	DirAccess.make_dir_recursive_absolute("user://gallery")
	var p := "user://gallery/" + fname
	current_image.save_png(p)
	status_label.text = "Saved (app folder): " + ProjectSettings.globalize_path(p)
