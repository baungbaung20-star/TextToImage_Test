extends Control
## On-device text-to-image, everything on the phone.
##  - Kotlin plugin "SdRunner" downloads the model and runs the bundled stable-diffusion.cpp server
##  - this UI talks to that server on http://127.0.0.1:7860 (AUTOMATIC1111-style API)
## Without the plugin (e.g. on desktop) you can type the URL of any compatible server.

const PLUGIN_NAME := "SdRunner"
const PORT := 7860
const DEFAULT_REPO := "concedo/sdxs-512-tinySDdistilled-GGUF" # small model (~0.7 GB), 1 step
const MODEL_NOTE := "user://model.txt" # remembers which .gguf file was downloaded
const TXT2IMG_PATH := "/sdapi/v1/txt2img"

var runner: Object = null
var model_path := ""
var server_ready := false
var server_exited := false

var url_edit: LineEdit
var prompt_edit: TextEdit
var steps_spin: SpinBox
var seed_spin: SpinBox
var cfg_spin: SpinBox
var size_opt: OptionButton
var download_btn: Button
var progress_bar: ProgressBar
var generate_btn: Button
var status_label: Label
var log_edit: TextEdit
var extra_edit: LineEdit
var repo_edit: LineEdit
var api_http: HTTPRequest
var model_url := ""
var preview: TextureRect
var save_btn: Button
var http: HTTPRequest
var current_image: Image
var busy := false
var elapsed := 0.0
var log_lines: PackedStringArray = PackedStringArray()


func _ready() -> void:
	_build_ui()
	http = HTTPRequest.new()
	http.timeout = 0 # generation can take minutes on a phone
	http.request_completed.connect(_on_request_completed)
	add_child(http)
	api_http = HTTPRequest.new()
	api_http.request_completed.connect(_on_repo_listed)
	add_child(api_http)
	_setup_runner()


func _process(delta: float) -> void:
	if busy:
		elapsed += delta
		status_label.text = "Generating... %d စက္ကန့် (ဖုန်းမှာ ကြာနိုင်ပါတယ်)" % int(elapsed)


# ---------------- UI ----------------

func _build_ui() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	add_child(margin)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 12)
	margin.add_child(vbox)

	var title := Label.new()
	title.text = "On-device Text to Image"
	title.add_theme_font_size_override("font_size", 32)
	vbox.add_child(title)

	url_edit = LineEdit.new()
	url_edit.text = "http://127.0.0.1:%d" % PORT
	url_edit.placeholder_text = "Server URL"
	vbox.add_child(url_edit)

	prompt_edit = TextEdit.new()
	prompt_edit.placeholder_text = "Prompt ရိုက်ထည့်ပါ... (English က ပိုကောင်းပါတယ်)"
	prompt_edit.custom_minimum_size = Vector2(0, 130)
	prompt_edit.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	prompt_edit.text = "a cozy wooden cabin in a snowy forest at sunset, detailed, digital art"
	vbox.add_child(prompt_edit)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	vbox.add_child(row)
	row.add_child(_label("Steps"))
	steps_spin = SpinBox.new()
	steps_spin.min_value = 1
	steps_spin.max_value = 50
	steps_spin.value = 1 # SDXS needs only 1 step
	row.add_child(steps_spin)
	row.add_child(_label("Seed"))
	seed_spin = SpinBox.new()
	seed_spin.min_value = 0
	seed_spin.max_value = 2147483647
	seed_spin.value = 0 # 0 = random
	row.add_child(seed_spin)

	var row2 := HBoxContainer.new()
	row2.add_theme_constant_override("separation", 12)
	vbox.add_child(row2)
	row2.add_child(_label("Size"))
	size_opt = OptionButton.new()
	for s in [256, 384, 512]:
		size_opt.add_item("%dx%d" % [s, s], s)
	size_opt.select(2)
	row2.add_child(size_opt)
	row2.add_child(_label("CFG"))
	cfg_spin = SpinBox.new()
	cfg_spin.min_value = 0.0
	cfg_spin.max_value = 15.0
	cfg_spin.step = 0.5
	cfg_spin.value = 1.0 # SDXS needs cfg 1
	row2.add_child(cfg_spin)

	repo_edit = LineEdit.new()
	repo_edit.text = DEFAULT_REPO
	repo_edit.placeholder_text = "Hugging Face model repo (owner/name)"
	vbox.add_child(repo_edit)

	download_btn = Button.new()
	download_btn.text = "Model download (~0.7 GB)"
	download_btn.custom_minimum_size = Vector2(0, 70)
	download_btn.visible = false
	download_btn.pressed.connect(_on_download_pressed)
	vbox.add_child(download_btn)

	progress_bar = ProgressBar.new()
	progress_bar.visible = false
	vbox.add_child(progress_bar)

	generate_btn = Button.new()
	generate_btn.text = "Generate"
	generate_btn.custom_minimum_size = Vector2(0, 80)
	generate_btn.pressed.connect(_on_generate_pressed)
	vbox.add_child(generate_btn)

	status_label = Label.new()
	status_label.text = "Ready"
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vbox.add_child(status_label)

	extra_edit = LineEdit.new()
	extra_edit.placeholder_text = "extra server options (optional)"
	vbox.add_child(extra_edit)

	var dbg := HBoxContainer.new()
	dbg.add_theme_constant_override("separation", 10)
	vbox.add_child(dbg)
	var copy_btn := Button.new()
	copy_btn.text = "Copy log"
	copy_btn.custom_minimum_size = Vector2(0, 60)
	copy_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	copy_btn.pressed.connect(_on_copy_log)
	dbg.add_child(copy_btn)
	var help_btn := Button.new()
	help_btn.text = "Server --help"
	help_btn.custom_minimum_size = Vector2(0, 60)
	help_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	help_btn.pressed.connect(_on_help_pressed)
	dbg.add_child(help_btn)
	var restart_btn := Button.new()
	restart_btn.text = "Restart engine"
	restart_btn.custom_minimum_size = Vector2(0, 60)
	restart_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	restart_btn.pressed.connect(_on_restart_pressed)
	dbg.add_child(restart_btn)

	log_edit = TextEdit.new()
	log_edit.editable = false
	log_edit.custom_minimum_size = Vector2(0, 320)
	log_edit.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	log_edit.placeholder_text = "engine log"
	vbox.add_child(log_edit)

	preview = TextureRect.new()
	preview.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	preview.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	preview.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(preview)

	save_btn = Button.new()
	save_btn.text = "Save"
	save_btn.disabled = true
	save_btn.custom_minimum_size = Vector2(0, 70)
	save_btn.pressed.connect(_on_save_pressed)
	vbox.add_child(save_btn)


func _label(t: String) -> Label:
	var l := Label.new()
	l.text = t
	return l


func _set_status(t: String) -> void:
	status_label.text = t


# ---------------- Engine (Kotlin plugin) ----------------

func _setup_runner() -> void:
	if not Engine.has_singleton(PLUGIN_NAME):
		_set_status("Plugin မတွေ့ပါ - ဒီ URL က server ကို သုံးပါမယ်")
		return
	runner = Engine.get_singleton(PLUGIN_NAME)
	runner.connect("sd_log", _on_sd_log)
	runner.connect("dl_progress", _on_dl_progress)
	runner.connect("dl_done", _on_dl_done)
	runner.connect("sd_exit", _on_sd_exit)
	runner.connect("sd_error", _on_sd_error)
	generate_btn.disabled = true
	var saved := ""
	if FileAccess.file_exists(MODEL_NOTE):
		saved = FileAccess.get_file_as_string(MODEL_NOTE).strip_edges()
	if not saved.is_empty():
		model_path = runner.modelPath(saved)
		if runner.fileExists(model_path):
			_start_engine()
			return
	download_btn.visible = true
	_set_status("Model (~0.7 GB) ကို download လုပ်ရပါမယ်။ WiFi သုံးပါ။")


func _on_download_pressed() -> void:
	download_btn.disabled = true
	progress_bar.visible = true
	progress_bar.value = 0
	_set_status("Model ဖိုင်အမည်ကို Hugging Face မှာ ရှာနေပါတယ်...")
	var repo := repo_edit.text.strip_edges()
	if api_http.request("https://huggingface.co/api/models/" + repo) != OK:
		_on_sd_error("Hugging Face ကို မချိတ်ဆက်နိုင်ပါ")


func _on_repo_listed(result: int, code: int, _h: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		_on_sd_error("Model repo မတွေ့ပါ (result %d, HTTP %d) - repo အမည်ကို စစ်ပါ" % [result, code])
		return
	var data = JSON.parse_string(body.get_string_from_utf8())
	var best := ""
	if typeof(data) == TYPE_DICTIONARY and data.has("siblings"):
		for f in data["siblings"]:
			var n := str(f.get("rfilename", ""))
			if n.to_lower().ends_with(".gguf") and "/" not in n:
				best = n
				break
	if best.is_empty():
		_on_sd_error("အဲဒီ repo ထဲမှာ .gguf ဖိုင် မတွေ့ပါ")
		return
	model_path = runner.modelPath(best)
	model_url = "https://huggingface.co/%s/resolve/main/%s" % [repo_edit.text.strip_edges(), best]
	_on_sd_log("model file: " + best)
	var note := FileAccess.open(MODEL_NOTE, FileAccess.WRITE)
	if note:
		note.store_string(best)
		note.close()
	_set_status("Download စတင်နေပါတယ်...")
	runner.downloadModel(model_url, model_path)


func _on_dl_progress(mb_done: int, mb_total: int) -> void:
	progress_bar.max_value = maxf(float(mb_total), 1.0)
	progress_bar.value = mb_done
	_set_status("Downloading %d / %d MB" % [mb_done, mb_total])


func _on_dl_done(_path: String) -> void:
	progress_bar.visible = false
	_start_engine()


func _start_engine() -> void:
	server_ready = false
	server_exited = false
	generate_btn.disabled = true
	download_btn.visible = false
	_set_status("Engine စတင်နေပါတယ်... model load ရတာ မိနစ်အနည်းငယ် ကြာနိုင်ပါတယ်")
	runner.startServer(model_path, PORT, extra_edit.text.strip_edges())
	_wait_server()


func _on_copy_log() -> void:
	DisplayServer.clipboard_set("\n".join(log_lines))
	_set_status("Log ကို copy ကူးပြီးပါပြီ - chat မှာ paste လုပ်ပါ")


func _on_help_pressed() -> void:
	if runner:
		runner.showHelp()
	else:
		_set_status("Plugin မတွေ့ပါ")


func _on_restart_pressed() -> void:
	if runner == null:
		return
	if not runner.fileExists(model_path):
		_set_status("Model မရှိသေးပါ - download အရင်လုပ်ပါ")
		return
	busy = false
	runner.stopServer()
	server_exited = true # stops any running _wait_server loop
	_set_status("Engine ကို ပြန်စတင်နေပါတယ်...")
	await get_tree().create_timer(2.0).timeout
	_start_engine()


func _wait_server() -> void:
	var waited := 0
	while waited < 900 and not server_exited:
		var ok: bool = await _tcp_ok()
		if ok:
			server_ready = true
			generate_btn.disabled = false
			_set_status("Ready")
			return
		await get_tree().create_timer(1.0).timeout
		waited += 1
	if not server_exited:
		_set_status("Engine မစတင်နိုင်ပါ (အချိန်ကုန်သွားပါပြီ) - log ကိုကြည့်ပါ")


func _tcp_ok() -> bool:
	var peer := StreamPeerTCP.new()
	if peer.connect_to_host("127.0.0.1", PORT) != OK:
		return false
	for i in 20:
		peer.poll()
		var st := peer.get_status()
		if st == StreamPeerTCP.STATUS_CONNECTED:
			peer.disconnect_from_host()
			return true
		if st == StreamPeerTCP.STATUS_ERROR or st == StreamPeerTCP.STATUS_NONE:
			return false
		await get_tree().create_timer(0.05).timeout
	peer.disconnect_from_host()
	return false


func _on_sd_log(line: String) -> void:
	log_lines.append(line)
	while log_lines.size() > 400:
		log_lines.remove_at(0)
	log_edit.text = "\n".join(log_lines)
	log_edit.scroll_vertical = log_edit.get_line_count()


func _on_sd_exit(code: int) -> void:
	server_exited = true
	server_ready = false
	busy = false
	generate_btn.disabled = true
	_set_status("Engine ရပ်/ပျက်သွားပါတယ် (code %d) - Copy log ကိုနှိပ်ပြီး chat မှာ paste လုပ်ပါ၊ ပြီးရင် Restart engine နှိပ်ပါ" % code)


func _on_sd_error(message: String) -> void:
	busy = false
	progress_bar.visible = false
	if runner and not runner.fileExists(model_path):
		download_btn.visible = true
		download_btn.disabled = false
	_set_status("Error: " + message)
	_on_sd_log("ERROR: " + message)


# ---------------- Generate ----------------

func _on_generate_pressed() -> void:
	if busy:
		return
	var prompt := prompt_edit.text.strip_edges()
	if prompt.is_empty():
		_set_status("Prompt ထည့်ပါ")
		return
	var seed_value := int(seed_spin.value)
	if seed_value == 0:
		seed_value = randi() % 2147483647
	var px := size_opt.get_selected_id()
	var body := JSON.stringify({
		"prompt": prompt,
		"negative_prompt": "",
		"steps": int(steps_spin.value),
		"seed": seed_value,
		"width": px,
		"height": px,
		"cfg_scale": cfg_spin.value,
	})
	var url := url_edit.text.strip_edges().rstrip("/") + TXT2IMG_PATH
	var err := http.request(url, ["Content-Type: application/json"], HTTPClient.METHOD_POST, body)
	if err != OK:
		_set_status("Request မပို့နိုင်ပါ (error %d). Server URL ကိုစစ်ပါ" % err)
		return
	busy = true
	elapsed = 0.0
	generate_btn.disabled = true
	save_btn.disabled = true


func _on_request_completed(result: int, code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	busy = false
	generate_btn.disabled = false
	if result != HTTPRequest.RESULT_SUCCESS:
		_set_status("Server နဲ့ မချိတ်ဆက်နိုင်ပါ (result %d)" % result)
		return
	if code != 200:
		_set_status("Server error %d: %s" % [code, body.get_string_from_utf8().left(200)])
		return
	var data = JSON.parse_string(body.get_string_from_utf8())
	if typeof(data) != TYPE_DICTIONARY or not data.has("images") or data["images"].is_empty():
		_set_status("Server ကပြန်လာတဲ့ response ကို နားမလည်ပါ")
		return
	var raw := Marshalls.base64_to_raw(str(data["images"][0]))
	var img := Image.new()
	var err := img.load_png_from_buffer(raw)
	if err != OK:
		err = img.load_jpg_from_buffer(raw)
	if err != OK:
		err = img.load_webp_from_buffer(raw)
	if err != OK:
		_set_status("ပုံဖတ်မရပါ (error %d)" % err)
		return
	_show_image(img)


func _show_image(img: Image) -> void:
	current_image = img
	preview.texture = ImageTexture.create_from_image(img)
	save_btn.disabled = false
	_set_status("Done (%dx%d) - %d စက္ကန့်" % [img.get_width(), img.get_height(), int(elapsed)])


func _on_save_pressed() -> void:
	if current_image == null:
		return
	var fname := "img_%d.png" % Time.get_unix_time_from_system()
	var pictures := OS.get_system_dir(OS.SYSTEM_DIR_PICTURES)
	if not pictures.is_empty():
		var path := pictures.path_join(fname)
		if current_image.save_png(path) == OK:
			_set_status("Saved: " + path)
			return
	DirAccess.make_dir_recursive_absolute("user://gallery")
	var p := "user://gallery/" + fname
	current_image.save_png(p)
	_set_status("Saved (app folder): " + ProjectSettings.globalize_path(p))
