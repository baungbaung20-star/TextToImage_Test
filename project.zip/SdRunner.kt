package com.example.imagegen

import android.util.Log
import org.godotengine.godot.Godot
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.SignalInfo
import org.godotengine.godot.plugin.UsedByGodot
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Godot Android plugin (v2), singleton name "SdRunner".
 *  - downloads the model file (resumable)
 *  - runs the bundled stable-diffusion.cpp server binary (packaged as libsdserver.so)
 * The Godot UI then talks to the server on http://127.0.0.1:<port>.
 */
class SdRunner(godot: Godot) : GodotPlugin(godot) {

    private val executor = Executors.newCachedThreadPool()
    @Volatile private var process: Process? = null
    @Volatile private var downloading = false

    override fun getPluginName() = "SdRunner"

    override fun getPluginSignals(): Set<SignalInfo> = setOf(
        SignalInfo("sd_log", String::class.java),
        SignalInfo("dl_progress", Int::class.javaObjectType, Int::class.javaObjectType),
        SignalInfo("dl_done", String::class.java),
        SignalInfo("sd_exit", Int::class.javaObjectType),
        SignalInfo("sd_error", String::class.java),
    )

    /** Full path where the model file lives (inside the app's private files dir). */
    @UsedByGodot
    fun modelPath(fileName: String): String {
        val dir = File(activity!!.filesDir, "models")
        dir.mkdirs()
        return File(dir, fileName).absolutePath
    }

    @UsedByGodot
    fun fileExists(path: String): Boolean {
        val f = File(path)
        return f.isFile && f.length() > 0
    }

    /** Resumable download. Emits dl_progress(MB done, MB total) and dl_done(path). */
    @UsedByGodot
    fun downloadModel(url: String, path: String) {
        if (downloading) return
        downloading = true
        executor.execute {
            try {
                val dest = File(path)
                val part = File("$path.part")
                var offset = if (part.exists()) part.length() else 0L
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 30000
                conn.readTimeout = 60000
                conn.instanceFollowRedirects = true
                conn.setRequestProperty("User-Agent", "OnDeviceTextToImage")
                if (offset > 0) conn.setRequestProperty("Range", "bytes=$offset-")
                val code = conn.responseCode
                if (code == 416 && part.exists()) {
                    part.renameTo(dest)
                    emitSignal("dl_done", dest.absolutePath)
                    return@execute
                }
                if (code != 200 && code != 206) throw RuntimeException("HTTP $code")
                if (code == 200) offset = 0L // server ignored Range, start over
                val total = offset + conn.contentLengthLong
                var done = offset
                var lastEmit = 0L
                conn.inputStream.use { input ->
                    FileOutputStream(part, offset > 0).use { out ->
                        val buf = ByteArray(256 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            val now = System.currentTimeMillis()
                            if (now - lastEmit > 700) {
                                lastEmit = now
                                emitSignal("dl_progress", (done / 1048576L).toInt(), (total / 1048576L).toInt())
                            }
                        }
                    }
                }
                if (total > 0 && done < total) throw RuntimeException("download incomplete ($done / $total)")
                if (dest.exists()) dest.delete()
                part.renameTo(dest)
                emitSignal("dl_done", dest.absolutePath)
            } catch (e: Exception) {
                Log.e(TAG, "download failed", e)
                emitSignal("sd_error", "download: ${e.message}")
            } finally {
                downloading = false
            }
        }
    }

    @UsedByGodot
    fun startServer(modelPath: String, port: Int) {
        stopServer()
        executor.execute {
            runExe(listOf("-m", modelPath, "--listen-ip", "127.0.0.1", "--listen-port", port.toString()))
        }
    }

    /** Runs "sd-server --help" so the options can be seen in the app log. */
    @UsedByGodot
    fun showHelp() {
        executor.execute { runExe(listOf("--help")) }
    }

    @UsedByGodot
    fun stopServer() {
        process?.destroy()
        process = null
    }

    private fun runExe(args: List<String>) {
        try {
            val dir = activity!!.applicationInfo.nativeLibraryDir
            val exe = File(dir, "libsdserver.so")
            if (!exe.exists()) {
                emitSignal("sd_error", "libsdserver.so not found in $dir (files: ${File(dir).list()?.joinToString()})")
                return
            }
            val pb = ProcessBuilder(listOf(exe.absolutePath) + args)
            pb.redirectErrorStream(true)
            pb.environment()["LD_LIBRARY_PATH"] = dir
            val p = pb.start()
            process = p
            p.inputStream.bufferedReader().forEachLine { emitSignal("sd_log", it.take(300)) }
            emitSignal("sd_exit", p.waitFor())
        } catch (e: Exception) {
            Log.e(TAG, "run failed", e)
            emitSignal("sd_error", "run: ${e.message}")
        }
    }

    override fun onMainDestroy() {
        stopServer()
        executor.shutdown()
    }

    companion object { private const val TAG = "SdRunner" }
}
