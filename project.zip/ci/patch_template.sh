#!/usr/bin/env bash
# Adds the SdRunner Kotlin plugin + the sd-server binary to Godot's Android build template.
set -euo pipefail

echo "== template layout =="
find android/build -maxdepth 3 -not -path '*/.*' | sort | head -80

# 1) AndroidManifest that holds the <application> element
MANIFEST=$(grep -rl --include=AndroidManifest.xml "</application>" android/build | awk '{print length, $0}' | sort -n | head -1 | cut -d' ' -f2-)
[ -n "$MANIFEST" ] || { echo "ERROR: no AndroidManifest.xml with </application>"; exit 1; }
echo "manifest: $MANIFEST"
MDIR=$(dirname "$MANIFEST")

# 2) Source root = the folder that contains com/godot/game/GodotApp.*
APP=$(find android/build -path '*/com/godot/game/GodotApp.*' | head -1)
if [ -n "$APP" ]; then
  SRCROOT=${APP%/com/godot/game/*}
elif [ "$(basename "$MDIR")" = "main" ]; then
  SRCROOT="$MDIR/java"
else
  SRCROOT="$MDIR/src/main/java"
fi
echo "source root: $SRCROOT"
mkdir -p "$SRCROOT/com/example/imagegen"
cp SdRunner.kt "$SRCROOT/com/example/imagegen/SdRunner.kt"

# 3) Register the plugin in the manifest
if ! grep -q "org.godotengine.plugin.v2.SdRunner" "$MANIFEST"; then
  sed -i 's#</application>#    <meta-data android:name="org.godotengine.plugin.v2.SdRunner" android:value="com.example.imagegen.SdRunner" />\n    </application>#' "$MANIFEST"
fi
grep -n "SdRunner" "$MANIFEST"

# 4) App gradle file: ship libsdserver.so as a native lib and keep it extracted (executable)
echo "== gradle files =="
find android/build -maxdepth 3 \( -name build.gradle -o -name build.gradle.kts \)
GRADLE=$(grep -rlE "com\.android\.application|android\.application" android/build --include=build.gradle --include=build.gradle.kts | awk '{print length, $0}' | sort -n | head -1 | cut -d' ' -f2-)
[ -n "$GRADLE" ] || GRADLE=android/build/build.gradle
echo "app gradle: $GRADLE"
GDIR=$(dirname "$GRADLE")
grep -qi kotlin "$GRADLE" || echo "WARNING: kotlin plugin not found in $GRADLE"

mkdir -p "$GDIR/extra_jni/arm64-v8a"
cp native/arm64-v8a/libsdserver.so "$GDIR/extra_jni/arm64-v8a/libsdserver.so"

if ! grep -q "extra_jni" "$GRADLE"; then
  case "$GRADLE" in
    *.kts)
      cat >> "$GRADLE" <<'EOF'

android.sourceSets["main"].jniLibs.srcDir("extra_jni")
android.packaging.jniLibs.useLegacyPackaging = true
EOF
      ;;
    *)
      cat >> "$GRADLE" <<'EOF'

android.sourceSets.main.jniLibs.srcDir 'extra_jni'
android.packaging.jniLibs.useLegacyPackaging = true
EOF
      ;;
  esac
fi
tail -5 "$GRADLE"
ls -la "$GDIR/extra_jni/arm64-v8a"
echo "patched OK"
