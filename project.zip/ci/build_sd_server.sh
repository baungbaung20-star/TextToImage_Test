#!/usr/bin/env bash
# Cross-compiles the stable-diffusion.cpp server for Android arm64 (NDK on the GitHub runner)
# and stages it as native/arm64-v8a/libsdserver.so
set -euo pipefail

NDK="${ANDROID_NDK_LATEST_HOME:-${ANDROID_NDK_HOME:-}}"
if [ -z "$NDK" ] || [ ! -d "$NDK" ]; then
  NDK=$(ls -d "${ANDROID_HOME:-/usr/local/lib/android/sdk}"/ndk/* 2>/dev/null | sort -V | tail -1)
fi
[ -d "$NDK" ] || { echo "ERROR: Android NDK not found"; exit 1; }
echo "NDK = $NDK"

git clone --depth 1 --recurse-submodules --shallow-submodules https://github.com/leejet/stable-diffusion.cpp sdcpp
echo "sd.cpp commit: $(git -C sdcpp rev-parse --short HEAD)"

cmake -S sdcpp -B sdcpp/build-android -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a \
  -DANDROID_PLATFORM=android-28 \
  -DCMAKE_BUILD_TYPE=Release \
  -DGGML_OPENMP=OFF \
  -DGGML_NATIVE=OFF \
  -DSD_BUILD_EXAMPLES=ON \
  -DSD_WEBP=OFF \
  -DSD_WEBM=OFF

cmake --build sdcpp/build-android -j"$(nproc)"

BIN=$(find sdcpp/build-android -type f \( -name 'sd-server' -o -name 'sd_server' \) | head -1)
if [ -z "$BIN" ]; then
  echo "ERROR: sd-server binary not found. Executables that were built:"
  find sdcpp/build-android -type f -perm -u+x -not -name '*.so' -not -name '*.a' | head -40
  exit 1
fi
echo "server binary: $BIN"

mkdir -p native/arm64-v8a
cp "$BIN" native/arm64-v8a/libsdserver.so
"$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip" native/arm64-v8a/libsdserver.so || true
ls -la native/arm64-v8a
file native/arm64-v8a/libsdserver.so || true
