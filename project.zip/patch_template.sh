#!/usr/bin/env bash
# Installs the OnDeviceImageGen plugin into Godot's Android build template (android/build).
# Used by the GitHub Actions workflow. Safe to run twice.
set -euo pipefail

B=android/build
[ -d "$B" ] || { echo "android/build not found"; exit 1; }

# 1) Kotlin source
D="$B/src/main/java/com/example/imagegen"
mkdir -p "$D"
cp ImageGenPlugin.kt "$D/ImageGenPlugin.kt"

# 2) Manifest: register the plugin + optional OpenCL
if ! grep -q "OnDeviceImageGen" "$B/AndroidManifest.xml"; then
  sed -i 's#</application>#    <meta-data android:name="org.godotengine.plugin.v2.OnDeviceImageGen" android:value="com.example.imagegen.ImageGenPlugin" />\n        <uses-native-library android:name="libOpenCL.so" android:required="false" />\n    </application>#' "$B/AndroidManifest.xml"
fi

# 3) MediaPipe dependency (first top-level "dependencies {" only)
if ! grep -q "tasks-vision-image-generator" "$B/build.gradle"; then
  sed -i '0,/^dependencies[[:space:]]*{/s//dependencies {\n    implementation "com.google.mediapipe:tasks-vision-image-generator:latest.release"/' "$B/build.gradle"
fi

grep -n "OnDeviceImageGen" "$B/AndroidManifest.xml"
grep -n "tasks-vision-image-generator" "$B/build.gradle"
echo "patched OK"
