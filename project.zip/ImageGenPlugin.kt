package com.example.imagegen

import android.graphics.Bitmap
import android.util.Log
import com.google.mediapipe.framework.image.BitmapExtractor
import com.google.mediapipe.tasks.vision.imagegenerator.ImageGenerator
import com.google.mediapipe.tasks.vision.imagegenerator.ImageGenerator.ImageGeneratorOptions
import org.godotengine.godot.Godot
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.SignalInfo
import org.godotengine.godot.plugin.UsedByGodot
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

/**
 * Godot 4.2+ Android plugin (v2). Exposed to GDScript as the singleton "OnDeviceImageGen".
 *
 * Model: MediaPipe-converted Stable Diffusion 1.5 directory, placed at
 *   <app files dir>/image_generator/   (or any path passed to loadModel(path))
 */
class ImageGenPlugin(godot: Godot) : GodotPlugin(godot) {

    private val executor = Executors.newSingleThreadExecutor()
    private var generator: ImageGenerator? = null

    override fun getPluginName() = "OnDeviceImageGen"

    override fun getPluginSignals(): Set<SignalInfo> = setOf(
        SignalInfo("model_loaded"),
        SignalInfo("progress", Int::class.javaObjectType, Int::class.javaObjectType),
        SignalInfo("image_ready", String::class.java),
        SignalInfo("error", String::class.java),
    )

    private fun defaultModelDir(): String {
        val ctx = activity ?: return ""
        return File(ctx.getExternalFilesDir(null), "image_generator").absolutePath
    }

    /** Pass "" to use the default directory. */
    @UsedByGodot
    fun loadModel(path: String) {
        executor.execute {
            try {
                val dir = if (path.isEmpty()) defaultModelDir() else path
                if (!File(dir).exists()) {
                    emitSignal("error", "Model directory မတွေ့ပါ: $dir")
                    return@execute
                }
                val options = ImageGeneratorOptions.builder()
                    .setImageGeneratorModelDirectory(dir)
                    .build()
                generator?.close()
                generator = ImageGenerator.createFromOptions(activity!!, options)
                emitSignal("model_loaded")
            } catch (e: Exception) {
                Log.e(TAG, "loadModel failed", e)
                emitSignal("error", "loadModel: ${e.message}")
            }
        }
    }

    @UsedByGodot
    fun generate(prompt: String, steps: Int, seed: Int) {
        val gen = generator
        if (gen == null) {
            emitSignal("error", "Model မ load ရသေးပါ")
            return
        }
        executor.execute {
            try {
                // Step-by-step execution so we can report progress.
                gen.setInputs(prompt, steps, seed)
                var last: Bitmap? = null
                for (i in 0 until steps) {
                    val showResult = (i == steps - 1)
                    val result = gen.execute(showResult)
                    emitSignal("progress", i + 1, steps)
                    if (showResult) {
                        last = result?.generatedImage()?.let { BitmapExtractor.extract(it) }
                    }
                }
                if (last == null) {
                    emitSignal("error", "Image မထွက်ပါ")
                    return@execute
                }
                val out = File(activity!!.cacheDir, "gen_${System.currentTimeMillis()}.png")
                FileOutputStream(out).use { last.compress(Bitmap.CompressFormat.PNG, 100, it) }
                emitSignal("image_ready", out.absolutePath)
            } catch (e: Exception) {
                Log.e(TAG, "generate failed", e)
                emitSignal("error", "generate: ${e.message}")
            }
        }
    }

    override fun onMainDestroy() {
        generator?.close()
        executor.shutdown()
    }

    companion object { private const val TAG = "OnDeviceImageGen" }
}
